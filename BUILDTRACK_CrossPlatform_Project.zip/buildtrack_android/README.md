# BUILDTRACK Android project

BUILDTRACK is a Zimbabwe-focused building budget tracker. The Android app wraps an offline-first interface in a WebView.

## MVP features
- Project name, location, budget and target completion date
- Record material, labour, transport, equipment, permit and other costs in USD
- Dashboard totals: budget, spent, remaining and percentage spent
- Overspending / near-budget warning
- Physical construction progress percentage
- Filterable expense records and individual record deletion
- CSV expense export and JSON backup/restore
- Local device storage; no account or cloud sync in this MVP

## Build an APK with Android Studio
Open this folder in Android Studio, allow Gradle sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK is usually created at `app/build/outputs/apk/debug/app-debug.apk`.

## Build an APK using GitHub Actions (no Android Studio needed on your computer)
1. Create or sign in to a GitHub account.
2. Create a new repository and upload the contents of this folder (the files inside `buildtrack_android`, not the parent folder).
3. Open the repository's **Actions** tab and select **Build BUILDTRACK APK**.
4. Click **Run workflow** if it has not started automatically, and wait for the run to finish successfully.
5. Open the completed run and download the artifact named **BUILDTRACK-debug-APK**. Extract the ZIP to get `app-debug.apk`.
6. Transfer the APK to your Android phone and open it. If Android asks, allow installing apps from that file manager/browser for this installation.

The GitHub workflow is configured to compile and upload the debug APK automatically. This environment does not have the Android SDK/Gradle installed and has no network access to download them, so no compiled APK is included in this archive.


## iPhone and Android home-screen version (PWA)
The `web_app/` folder is a progressive web app version with an app manifest, icons and offline caching. It can be added to an iPhone home screen from Safari after it is hosted over HTTPS.

### Publish the web app with GitHub Pages
1. Upload the contents of this project to a GitHub repository, keeping the `web_app` folder and `.github/workflows` files.
2. In the repository, open **Settings → Pages** and set the source to **GitHub Actions** if asked.
3. Open **Actions**, select **Deploy BUILDTRACK web app**, then run the workflow (or push a commit to `main`).
4. When the workflow completes, open the published Pages URL on your iPhone using Safari. Tap **Share → Add to Home Screen**. On Android, open the same URL in Chrome and choose **Install app** or **Add to Home screen**.

### Native iOS app note
This PWA is installable from Safari but is not an App Store/TestFlight `.ipa`. A native iOS build requires an Apple signing/distribution workflow, usually Xcode on macOS or a compatible cloud build service, plus Apple Developer account enrollment for TestFlight/App Store distribution. Never share your Apple ID password or verification codes in chat.
