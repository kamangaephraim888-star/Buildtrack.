# BUILDTRACK on iPhone and Android

## iPhone: install the web app (no App Store submission required)

1. Publish this project to a GitHub repository and enable the **GitHub Pages** deployment workflow under **Settings → Actions → General** if GitHub asks for workflow permissions.
2. Open the repository's **Actions** tab and run **Publish BUILDTRACK iPhone Web App**, or push a change to the `main` branch.
3. Wait for the workflow to succeed. Open **Settings → Pages** or the workflow deployment URL to get the HTTPS site address.
4. On the iPhone, open that HTTPS address in **Safari**.
5. Tap **Share → Add to Home Screen → Add**. Launch BUILDTRACK from the new Home Screen icon.

This is an installable web app (PWA), not a signed native `.ipa`. It can cache its app files for offline opening; user data is stored locally in that browser/app installation. Use **Project → Export full backup (JSON)** regularly. iOS may manage or clear website storage, so this is not a substitute for backups.

## Android APK

Use the existing GitHub Actions workflow **Build BUILDTRACK APK**. After it succeeds, download the `BUILDTRACK-debug-APK` artifact and extract `app-debug.apk`.

## Native iOS app

A native `.ipa` requires an Apple build/signing workflow, usually a macOS build runner and Apple Developer signing setup. An Apple ID alone does not automatically provide a signed `.ipa`. Never share your Apple ID password or verification codes in chat.
